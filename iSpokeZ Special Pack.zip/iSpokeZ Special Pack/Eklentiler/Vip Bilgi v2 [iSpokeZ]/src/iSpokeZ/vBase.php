<?php

/*
*   _  _____             _        ______
* (_)/ ____|           | |      |___  /
*  _| (___  _ __   ___ | | _____   / /
* | |\___ \| '_ \ / _ \| |/ / _ \ / /
* | |____) | |_) | (_) |   <  __// /__
* |_|_____/| .__/ \___/|_|\_\___/_____|
*          | |
*          |_|
*
* @Plugin Author - iSpokeZ
*
* @Plugin Language - Turkish
*
* @Plugin API - 3.8.4
*
* @Tüm Hakları Saklıdır.
*
* @Plugin Umut Yıldırım Tarafından Özel Olarak Kodlanmıştır.
*
*/

namespace iSpokeZ;

# PLUGIN #
use pocketmine\plugin\PluginBase;
use pocketmine\Player;

# COMMAND #
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class vBase extends PluginBase {

    public function onEnable(){
        $this->getLogger()->info("§aVIP Bilgi Aktif [iSpokeZ]");
    }

    public function onCommand(CommandSender $sender, Command $kmt, string $label, array $args): bool{
        if($kmt->getName() == "vipbilgi"){
            if($sender instanceof Player){
                $form = $this->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function(Player $oyuncu, array $data){
                    $result = $data[0];
                    if($result === null){
                        return true;
                    }
                    switch ($result){
                        case 0:
                            break;
                    }
                });
                $oyuncu = $sender->getPlayer();
                $form->setTitle("VIP Bilgi");
                $form->setContent("§7» §aSunucu Doluyken Girebilme\n§7» §aÖzelleştirilmiş RVIP Kiti\n§7» §aSohbette Beyaz Renkte Yazabilme\n§7» §a3.000TL Oyun Parası\n§7» §aPelerin Özelliği\n§7» §aÖzel VIP Kasası Açabilme\n§7» §aSınırsız Açlık Doldurma\n§7» §a12 Saatte Bir Duyuru Yapma Hakkı\n\n§7» §dFiyat§7: §e10TL §7[Aylık]");
                $form->addButton("Ayrıl");
                $form->sendToPlayer($oyuncu);
            }
        }
        return true;
    }
}