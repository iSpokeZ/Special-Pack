<?php

namespace iSpokeZ\events;

//Plugin
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\Server;
use iSpokeZ\Base;
use pocketmine\utils\TextFormat as C;

//Event
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;

//Level
use pocketmine\level\sound\GhastShootSound;

class Event implements Listener {

  private $plugin;

  public function __construct(Base $plugin){
    $this->plugin = $plugin;
  }

  public function join(PlayerJoinEvent $event){
    $oyuncu = $event->getPlayer();
    $isim = $oyuncu->getName();

    $oyuncu->addTitle(C::RED . "LifeNetwork\n" . C::YELLOW . "Hoşgeldin");
    $oyuncu->getLevel()->addSound(new GhastShootSound($oyuncu));
    $event->setJoinMessage(C::GRAY . "(" . C::GREEN . "+" . C::GRAY . ")" . C::YELLOW . " $isim");
    $oyuncu->sendMessage(C::GREEN . "Sunucuya Hoşgeldin Dostum!");
  }
}
