<?php

namespace iSpokeZ\commands;

//Command
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

//Plugin
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\Server;
use iSpokeZ\Base;

//TELEPORT
use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\level\Position;

class Lobi extends Command {

  private $plugin;

  public function __construct(Base $plugin){
    parent::__construct("lobi", "Lobi Alanına Işınlar", "/lobi");
    $this->plugin = $plugin;
  }

  public function execute(CommandSender $sender, string $label, array $args){
    $oyuncu = $sender->getPlayer();

    Base::getAPI()->getServer()->loadLevel("Default");
    $dunya = Base::getAPI()->getServer()->getLevelByName("Default");
    $base = $dunya->getSafeSpawn();
    $oyuncu->teleport($base, 0, 0);
    $oyuncu->teleport(new Vector3($base->getX(), $base->getY(), $base->getZ()));
    $oyuncu->sendMessage("§aLobi'ye Işınlandın!");
  }
}
