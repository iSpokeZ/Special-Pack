<?php

namespace iSpokeZ\commands;

# PLUGIN #
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;
use iSpokeZ\Base;
use pocketmine\Player;
use onebone\economyapi\EconomyAPI;
use pocketmine\Server;
use iSpokeZ\forms\Form;
use pocketmine\utils\Config;
use iSpokeZ\forms\ModalForm;
use pocketmine\item\Item;
use pocketmine\utils\TextFormat as C;

# COMMAND #
use pocketmine\command\Command;
use pocketmine\command\CommandSender;

# LEVEL #
use pocketmine\level\sound\GhastShootSound;

class Kit extends Command {

  public $sure = C::RED . "1 Gün Geçmeden Tekrar Kit Alamazsın";

  public $yetkiyok = C::RED . "Bu Kiti Almak Için Yetkin Yok";

  private $plugin;

  public function __construct(Base $plugin){
  parent::__construct("kit", "Advanced kit system", "/kit");
  $this->plugin = $plugin;
  }

  public function execute(CommandSender $sender, string $label, array $args){
    $player = $sender->getPlayer();

    $form = Base::getAPI()->getServer()->getPluginManager()->getPlugin("FormAPI")->createSimpleForm(function (Player $player, array $data){
      $result = $data[0];
      if($result === null){
        return true;
      }
      switch($result){
        case 0:
        if(!$player->hasPermission("ak.oyuncu")){
          $player->sendMessage($this->yetkiyok);
        }else{
          $this->oyuncu($player);
        }
        break;
        case 1:
        if(!$player->hasPermission("ak.youtube")){
          $player->sendMessage($this->yetkiyok);
        }else{
          $this->youtube($player);
        }
        break;
        case 2:
        if(!$player->hasPermission("ak.vip")){
          $player->sendMessage($this->yetkiyok);
        }else{
          $this->vip($player);
        }
        break;
        case 3:
        if(!$player->hasPermission("ak.mvip")){
          $player->sendMessage($this->yetkiyok);
        }else{
          $this->mvip($player);
        }
        break;
        case 4:
        break;
      }
    });

    /*
    * Main Form
    */
    $form->setTitle("Advanced Kit");
    $form->setContent(C::GRAY . "Aşağıdan Kitini Seçerek O Kite Sahip Olabilirsin");
    $form->addButton("Oyuncu Kiti\n" . C::GRAY . "Tıkla", 0,"textures/ui/icon_armor");
    $form->addButton("YouTube Kiti\n" . C::GRAY . "Tıkla", 0,"textures/ui/icon_armor");
    $form->addButton("VIP Kiti\n" . C::GRAY . "Tıkla", 0,"textures/ui/icon_armor");
    $form->addButton("MVIP Kiti\n" . C::GRAY . "Tıkla", 0,"textures/ui/icon_armor");
    $form->addButton(C::RED . "Ayrıl", 0,"textures/ui/realms_red_x");
    $form->sendToPlayer($player);
  }

  /*
  * Oyuncu Kit
  */
  public function oyuncu(Player $player){
    $form = new ModalForm(function (Player $player, $data){
      if($data === null){
        return true;
      }
      switch($data){
        case 1:

        $this->data = new Config(Base::getAPI()->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
        $sas = $this->data->get($player->getName());

        if($sas["Baslangıc"] >= $sas["Bitis"]){

        $player->getInventory()->addItem(Item::get(272, 0, 1)->setCustomName("§eOyuncu Kılıcı"));
        $player->getInventory()->addItem(Item::get(273, 0, 1)->setCustomName("§eOyuncu Küreği"));
        $player->getInventory()->addItem(Item::get(274, 0, 1)->setCustomName("§eOyuncu Kazması"));
        $player->getInventory()->addItem(Item::get(275, 0, 1)->setCustomName("§eOyuncu Baltası"));
        $player->getInventory()->addItem(Item::get(291, 0, 1)->setCustomName("§eOyuncu Çapası"));
        $player->getInventory()->addItem(Item::get(298, 0, 1)->setCustomName("§eOyuncu Kaskı"));
        $player->getInventory()->addItem(Item::get(299, 0, 1)->setCustomName("§eOyuncu Zırhı"));
        $player->getInventory()->addItem(Item::get(300, 0, 1)->setCustomName("§eOyuncu Pantolonu"));
        $player->getInventory()->addItem(Item::get(301, 0, 1)->setCustomName("§eOyuncu Botu"));
        EconomyAPI::getInstance()->addMoney($player, 1000);
        $player->getLevel()->addSound(new GhastShootSound($player));
        $player->addTitle("§eKit Aldın", "§7Oyuncu");
        $bas = date("d.m.Y");
        $son = strtotime("1 day", strtotime($bas));
        $son = date("d.m.Y", $son);
        $this->data->set($player->getName(),
            [
                "Baslangıc" => $bas,
                "Bitis" => $son
            ]);
        $this->data->save();
      }else{
        $player->sendMessage($this->sure);
      }
        break;
        case 2:
        break;
      }
    });
    $form->setTitle("Oyuncu Kiti");
    $form->setContent("\nKit İsmi: §eOyuncu\n\n§fKit İçeriği;\n§eDeri Kask\n§eDeri Zırh\n§eDeri Pantolon\n§eDeri Bot\n§eTaş Kılıç\n§eTaş Kazma\n§eTaş Balta\n§eTaş Kürek\n§eTaş Çapa\n§e1.000TL\n\n§fKiti Almak Için '§aOnayla' §fButonuna, Geri Dönmek Için '§cAyrıl' §fButonuna Bas\n" . " ");
    $form->setButton1("§aOnayla");
    $form->setButton2("§cAyrıl");
    $form->sendToPlayer($player);
  }

  /*
  * YouTube Kit
  */
  public function youtube(Player $player){
    $form = new ModalForm(function (Player $player, $data){
      if($data === null){
        return true;
      }
      switch($data){
        case 1:

        $this->data = new Config(Base::getAPI()->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
        $sas = $this->data->get($player->getName());

        if($sas["Baslangıc"] >= $sas["Bitis"]){

        $player->getInventory()->addItem(Item::get(267, 0, 1)->setCustomName("§eYouTuber Kılıcı"));
        $player->getInventory()->addItem(Item::get(256, 0, 1)->setCustomName("§eYouTuber Küreği"));
        $player->getInventory()->addItem(Item::get(257, 0, 1)->setCustomName("§eYouTuber Kazması"));
        $player->getInventory()->addItem(Item::get(258, 0, 1)->setCustomName("§eYouTuber Baltası"));
        $player->getInventory()->addItem(Item::get(292, 0, 1)->setCustomName("§eYouTuber Çapası"));
        $player->getInventory()->addItem(Item::get(302, 0, 1)->setCustomName("§eYouTuber Kaskı"));
        $player->getInventory()->addItem(Item::get(303, 0, 1)->setCustomName("§eYouTuber Zırhı"));
        $player->getInventory()->addItem(Item::get(304, 0, 1)->setCustomName("§eYouTuber Pantolonu"));
        $player->getInventory()->addItem(Item::get(305, 0, 1)->setCustomName("§eYouTuber Botu"));
        EconomyAPI::getInstance()->addMoney($player, 3000);
        $player->getLevel()->addSound(new GhastShootSound($player));
        $player->addTitle("§eKit Aldın", "§7YouTuber");
        $bas = date("d.m.Y");
        $son = strtotime("1 day", strtotime($bas));
        $son = date("d.m.Y", $son);
        $this->data->set($player->getName(),
            [
                "Baslangıc" => $bas,
                "Bitis" => $son
            ]);
        $this->data->save();
      }else{
        $player->sendMessage($this->sure);
      }
        break;
        case 2:
        break;
      }
    });
    $form->setTitle("YouTuber Kiti");
    $form->setContent("\nKit İsmi: §eYouTuber\n\n§fKit İçeriği;\n§eZincir Kask\n§eZincir Zırh\n§eZincir Pantolon\n§eZincir Bot\n§eDemir Kılıç\n§eDemir Kazma\n§eDemir Balta\n§eDemir Kürek\n§eDemir Çapa\n§e3.000TL\n\n§fKiti Almak Için '§aOnayla' §fButonuna, Geri Dönmek Için '§cAyrıl' §fButonuna Bas\n" . " ");
    $form->setButton1("§aOnayla");
    $form->setButton2("§cAyrıl");
    $form->sendToPlayer($player);
  }

  /*
  * VIP Kit
  */
  public function vip(Player $player){
    $form = new ModalForm(function (Player $player, $data){
      if($data === null){
        return true;
      }
      switch($data){
        case 1:

        $this->data = new Config(Base::getAPI()->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
        $sas = $this->data->get($player->getName());

        if($sas["Baslangıc"] >= $sas["Bitis"]){

        $player->getInventory()->addItem(Item::get(267, 0, 1)->setCustomName("§eVIP Kılıcı"));
        $player->getInventory()->addItem(Item::get(256, 0, 1)->setCustomName("§eVIP Küreği"));
        $player->getInventory()->addItem(Item::get(257, 0, 1)->setCustomName("§eVIP Kazması"));
        $player->getInventory()->addItem(Item::get(258, 0, 1)->setCustomName("§eVIP Baltası"));
        $player->getInventory()->addItem(Item::get(292, 0, 1)->setCustomName("§eVIP Çapası"));
        $player->getInventory()->addItem(Item::get(306, 0, 1)->setCustomName("§eVIP Kaskı"));
        $player->getInventory()->addItem(Item::get(307, 0, 1)->setCustomName("§eVIP Zırhı"));
        $player->getInventory()->addItem(Item::get(308, 0, 1)->setCustomName("§eVIP Pantolonu"));
        $player->getInventory()->addItem(Item::get(309, 0, 1)->setCustomName("§eVIP Botu"));
        EconomyAPI::getInstance()->addMoney($player, 7000);
        $player->getLevel()->addSound(new GhastShootSound($player));
        $player->addTitle("§eKit Aldın", "§7VIP");
        $bas = date("d.m.Y");
        $son = strtotime("1 day", strtotime($bas));
        $son = date("d.m.Y", $son);
        $this->data->set($player->getName(),
            [
                "Baslangıc" => $bas,
                "Bitis" => $son
            ]);
        $this->data->save();
      }else{
        $player->sendMessage($this->sure);
      }
        break;
        case 2:
        break;
      }
    });
    $form->setTitle("VIP Kiti");
    $form->setContent("\nKit İsmi: §eVIP\n\n§fKit İçeriği;\n§eDemir Kask\n§eDemir Zırh\n§eDemir Pantolon\n§eDemir Bot\n§eDemir Kılıç\n§eDemir Kazma\n§eDemir Balta\n§eDemir Kürek\n§eDemir Çapa\n§e7.000TL\n\n§fKiti Almak Için '§aOnayla' §fButonuna, Geri Dönmek Için '§cAyrıl' §fButonuna Bas\n" . " ");
    $form->setButton1("§aOnayla");
    $form->setButton2("§cAyrıl");
    $form->sendToPlayer($player);
  }

  /*
  * MVIP Kit
  */
  public function mvip(Player $player){
    $form = new ModalForm(function (Player $player, $data){
      if($data === null){
        return true;
      }
      switch($data){
        case 1:

        $this->data = new Config(Base::getAPI()->getDataFolder()."Oyuncular/".$player->getName().".yml", Config::YAML);
        $sas = $this->data->get($player->getName());

        if($sas["Baslangıc"] >= $sas["Bitis"]){

        $player->getInventory()->addItem(Item::get(276, 0, 1)->setCustomName("§eMVIP Kılıcı"));
        $player->getInventory()->addItem(Item::get(277, 0, 1)->setCustomName("§eMVIP Küreği"));
        $player->getInventory()->addItem(Item::get(278, 0, 1)->setCustomName("§eMVIP Kazması"));
        $player->getInventory()->addItem(Item::get(279, 0, 1)->setCustomName("§eMVIP Baltası"));
        $player->getInventory()->addItem(Item::get(293, 0, 1)->setCustomName("§eMVIP Çapası"));
        $player->getInventory()->addItem(Item::get(310, 0, 1)->setCustomName("§eMVIP Kaskı"));
        $player->getInventory()->addItem(Item::get(311, 0, 1)->setCustomName("§eMVIP Zırhı"));
        $player->getInventory()->addItem(Item::get(312, 0, 1)->setCustomName("§eMVIP Pantolonu"));
        $player->getInventory()->addItem(Item::get(313, 0, 1)->setCustomName("§eMVIP Botu"));
        EconomyAPI::getInstance()->addMoney($player, 13000);
        $player->getLevel()->addSound(new GhastShootSound($player));
        $player->addTitle("§eKit Aldın", "§7MVIP");
        $bas = date("d.m.Y");
        $son = strtotime("1 day", strtotime($bas));
        $son = date("d.m.Y", $son);
        $this->data->set($player->getName(),
            [
                "Baslangıc" => $bas,
                "Bitis" => $son
            ]);
        $this->data->save();
      }else{
        $player->sendMessage($this->sure);
      }
        break;
        case 2:
        break;
      }
    });
    $form->setTitle("MVIP Kiti");
    $form->setContent("\nKit İsmi: §eMVIP\n\n§fKit İçeriği;\n§eElmas Kask\n§eElmas Zırh\n§eElmas Pantolon\n§eElmas Bot\n§eElmas Kılıç\n§eElmas Kazma\n§eElmas Balta\n§eElmas Kürek\n§eElmas Çapa\n§e13.000TL\n\n§fKiti Almak Için '§aOnayla' §fButonuna, Geri Dönmek Için '§cAyrıl' §fButonuna Bas\n" . " ");
    $form->setButton1("§aOnayla");
    $form->setButton2("§cAyrıl");
    $form->sendToPlayer($player);
  }
}

 ?>
