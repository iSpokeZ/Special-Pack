<?php

/*
*   _  _____             _        ______
* (_)/ ____|           | |      |___  /
*  _| (___  _ __   ___ | | _____   / /
* | |\___ \| '_ \ / _ \| |/ / _ \ / /
* | |____) | |_) | (_) |   <  __// /__
* |_|_____/| .__/ \___/|_|\_\___/_____|
*          | |
*          |_|
*
* @Plugin Author - iSpokeZ
*
* @Plugin Language - Turkish
*
* @Plugin API - 3.9.1
*
* @Tüm Hakları Saklıdır.
*
* @Plugin Umut Yıldırım Tarafından Özel Olarak Kodlanmıştır.
*
*/

namespace iSpokeZ;

# PLUGIN #
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;
use iSpokeZ\Base;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as C;
use iSpokeZ\commands\Kit;

# COMMAND #
use pocketmine\command\CommandSender;
use pocketmine\command\Command;

class Base extends PluginBase {

  /**
  * @var $api
  */
  private static $api;

  /**
  * @return Base
  */

  public static function getAPI(): Base{
      return self::$api;
  }

  public function onLoad(){
      self::$api = $this;
  }

  /*
  * onEnable
  */
  public function onEnable(){
    $this->getLogger()->info("\nAdvancedKit Activated.\nAuthor: iSpokeZ");
    $this->getServer()->getCommandMap()->register("kit", new Kit ($this));
    @mkdir($this->getDataFolder());
    @mkdir($this->getDataFolder()."Oyuncular/");
  }
}

 ?>
