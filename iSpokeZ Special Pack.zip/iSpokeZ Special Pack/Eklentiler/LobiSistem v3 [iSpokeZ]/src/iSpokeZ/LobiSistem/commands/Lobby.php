<?php

/*
  _  _____             _        ______
 (_)/ ____|           | |      |___  /
  _| (___  _ __   ___ | | _____   / /
 | |\___ \| '_ \ / _ \| |/ / _ \ / /
 | |____) | |_) | (_) |   <  __// /__
 |_|_____/| .__/ \___/|_|\_\___/_____|
          | |
          |_|
*/

namespace iSpokeZ\LobiSistem\commands;

use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\plugin\Plugin;
use pocketmine\math\Vector3;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\Server;

use iSpokeZ\LobiSistem\Main;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Lobby extends Command {

    public $prefix = "§7[§6LobiSistem§7] ";

    private $plugin;

    /*** Constructor ***/
    public function __construct(Main $plugin){
        parent::__construct("lobi", "Lobby command", "/lobi");
        $this->plugin = $plugin;
    }

    /*** Command ***/
    public function execute(CommandSender $sender, string $label, array $args){
        $player = $sender->getPlayer();

        $player->getLevel()->addSound(new EndermanTeleportSound($player));
        $player->teleport(Main::getAPI()->getServer()->getDefaultLevel()->getSafeSpawn());
        $player->sendMessage($this->prefix . "§aBaşarıyla lobiye ışınlandın.");
    }
}
