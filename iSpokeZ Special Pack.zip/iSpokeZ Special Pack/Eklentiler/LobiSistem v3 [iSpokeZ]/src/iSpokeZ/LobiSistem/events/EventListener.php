<?php

/*
  _  _____             _        ______
 (_)/ ____|           | |      |___  /
  _| (___  _ __   ___ | | _____   / /
 | |\___ \| '_ \ / _ \| |/ / _ \ / /
 | |____) | |_) | (_) |   <  __// /__
 |_|_____/| .__/ \___/|_|\_\___/_____|
          | |
          |_|
*/

namespace iSpokeZ\LobiSistem\events;

use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use onebone\economyapi\EconomyAPI;

use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerBlockPickEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageEvent;

use pocketmine\level\sound\GhastShootSound;

use iSpokeZ\LobiSistem\Main;
use iSpokeZ\LobiSistem\forms\Form;
use iSpokeZ\LobiSistem\forms\FormAPI;
use iSpokeZ\LobiSistem\forms\CustomForm;
use iSpokeZ\LobiSistem\forms\SimpleForm;
use iSpokeZ\LobiSistem\forms\ModalForm;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class EventListener implements Listener {

    public $prefix = "§7[§6LobiSistem§7] ";

    private $plugin;

    /*** Constructor ***/
    public function __construct(Main $plugin){
        $this->plugin = $plugin;
    }

    /*** Items ***/
    public function items($player){
        $inv = $player->getInventory();

        $inv->clearAll();
        $item1 = Item::get(403, 0, 1);
        $item2 = Item::get(288, 0, 1);
        $item3 = Item::get(345, 0, 1);
        $item4 = Item::get(351, 1, 0);
        $item5 = Item::get(264, 0, 1);

        $item1->setCustomName("§l§cBilgi");
        $item2->setCustomName("§l§eZıpla");
        $item3->setCustomName("§l§dOyunlar");
        $item4->setCustomName("§l§7Oyuncu Gizle/Göster");
        $item5->setCustomName("§l§aMarket");

        $item1->setLore(["Bilgi Eşyası"]);
        $item2->setLore(["Zıplama Eşyası"]);
        $item3->setLore(["Oyun Menüsü"]);
        $item4->setLore(["Oyuncu Gizle/Göster"]);
        $item5->setLore(["Market Menüsü"]);

        $inv->setItem(0,$item1);
        $inv->setItem(3,$item2);
        $inv->setItem(4,$item3);
        $inv->setItem(5,$item4);
        $inv->setItem(8,$item5);
    }

    /*** Join Event ***/
    public function onJoin(PlayerJoinEvent $event){
        $player = $event->getPlayer();
        $name = $player->getName();

        $this->items($player);

        $player->addTitle("Sunucu Adı", "Mesaj");
        $event->setJoinMessage($this->prefix . "§e$name §asunucuya katıldı.");
        $player->sendMessage($this->prefix . "§cSunucuya hoşgeldin §7$name");
        $player->getLevel()->addSound(new GhastShootSound($player));

        $form = new SimpleForm(function (Player $player, $data){

            if($data === null){
                return;
            }
            switch($data){
                case 0:
                    break;
            }
        });
        $form->setTitle("Giriş");
        $form->setContent("Giriş Mesajı...");
        $form->addButton("Tamam");
        $form->sendToPlayer($player);
    }

    /*** Quit Event ***/
    public function onQuit(PlayerQuitEvent $event){
        $player = $event->getPlayer();
        $name = $player->getName();

        $event->setQuitMessage($this->prefix . "§e$name §asunucudan ayrıldı.");
    }

    /*** Interact Event ***/
    public function onInteract(PlayerInteractEvent $event){
        $player = $event->getPlayer();

        if($player->getInventory()->getItemInHand()->getCustomName() == "§l§cBilgi"){
            $form = new SimpleForm(function (Player $player, $data){

                if($data === null){
                    return;
                }
                switch($data){
                    case 0:
                        break;
                }
            });
            $form->setTitle("Bilgi");
            $form->setContent("Yazılacak");
            $form->addButton("Tamam");
            $form->sendToPlayer($player);
        }

        if($player->getInventory()->getItemInHand()->getCustomName() == "§l§eZıpla"){
            $x = $player->getX();
            $y = $player->getY();
            $z = $player->getZ();
            $player->teleport(new Vector3($x, $y + 7, $z));
            $player->sendPopup("Uçuyorsun");
        }

        if($player->getInventory()->getItemInHand()->getCustomName() == "§l§dOyunlar"){
            $form = new SimpleForm(function (Player $player, $data){

                if($data === null){
                    return;
                }
                switch($data){
                    case 0:
                        break;
                }
            });
            $form->setTitle("Oyunlar");
            $form->setContent("Oyun Menüsü");
            $form->addButton("Oyun Ekle...");
            $form->sendToPlayer($player);
        }

        if($player->getInventory()->getItemInHand()->getCustomName() == "§l§7Oyuncu Gizle/Göster"){
            $form = new SimpleForm(function (Player $player, $data){

                if($data === null){
                    return;
                }
                switch($data){
                    case 0:
                        foreach(Main::getAPI()->getServer()->getOnlinePlayers() as $players){
                            $player->hidePlayer($players);
                            $player->sendMessage($this->prefix . "§aOyuncular başarıyla gizlendi.");
                            $player->getLevel()->addSound(new GhastShootSound($player));
                        }
                        break;
                    case 1:
                        foreach(Main::getAPI()->getServer()->getOnlinePlayers() as $players){
                            $player->showPlayer($players);
                            $player->sendMessage($this->prefix . "§aOyuncular başarıyla gösterildi.");
                            $player->getLevel()->addSound(new GhastShootSound($player));
                        }
                        break;
                    case 2:
                        break;
                }
            });
            $form->setTitle("Oyuncu Gizleme Menüsü");
            $form->setContent("§7Aşağıdaki butonlardan oyuncuları gizleyebilir veya açabilirsin.");
            $form->addButton("Oyuncuları Gizle");
            $form->addButton("Oyuncuları Göster");
            $form->addButton("§cAyrıl");
            $form->sendToPlayer($player);
        }

        if($player->getInventory()->getItemInHand()->getCustomName() == "§l§aMarket"){
            $form = new SimpleForm(function (Player $player, $data){

                if($data === null){
                    return;
                }
                switch($data){
                    case 0:
                        break;
                }
            });
            $form->setTitle("Market");
            $form->setContent("§7Marketten eşya satın al.");
            $form->addButton("Ekle...");
            $form->sendToPlayer($player);
        }
    }

    /*** Respawn Event ***/
    public function onRespawn(PlayerRespawnEvent $event){
        $player = $event->getPlayer();
        $this->items($player);
    }

    /*** Exhaust Event ***/
    public function onExhaust(PlayerExhaustEvent $event){
        $player = $event->getPlayer();

        if($player->getLevel()->getFolderName() == "world"){
            $event->setCancelled(true);
        }
    }

    /*** Break Event ***/
    public function onBreak(BlockBreakEvent $event){
        $player = $event->getPlayer();

        if ($player->getLevel()->getFolderName() == "world") {
            if(!$player->isOp()){
                $event->setCancelled(true);
            }else{
                $event->setCancelled(false);
            }
        }
    }

    /*** Place Event ***/
    public function onPlace(BlockPlaceEvent $event){
        $player = $event->getPlayer();

        if ($player->getLevel()->getFolderName() == "world") {
            if(!$player->isOp()){
                $event->setCancelled(true);
            }else{
                $event->setCancelled(false);
            }
        }
    }

    /*** Damage Event ***/
    public function onDamage(EntityDamageEvent $event){
        if($event->getCause() === EntityDamageEvent::CAUSE_ENTITY_ATTACK or $event->getCause() === EntityDamageEvent::CAUSE_FALL){
            $event->setCancelled(true);
        }
    }

    /*** Drop Event ***/
    public function onDrop(PlayerDropItemEvent $event){
        $player = $event->getPlayer();

        if(!$player->isOp()){
            $event->setCancelled(true);
        }else{
            $event->setCancelled(false);
        }
    }

    /*** Chat Event ***/
    public function onChat(PlayerChatEvent $event){
        $player = $event->getPlayer();

        if($player->getLevel()->getFolderName() == "world") {
            if(!$player->hasPermission(chat.ls)){
                $event->setCancelled(true);
                $player->sendMessage("§cLobi'de Konuşmak Için VIP Üye Olmalısın");
        }else{
                $event->setCancelled(false);
            }
        }
    }

    /*** Pick Event ***/
    public function onPick(PlayerBlockPickEvent $event){
        $player = $event->getPlayer();

        if(!$player->isOp()){
            $event->setCancelled(true);
        }else{
            $event->setCancelled(false);
        }
    }
}
