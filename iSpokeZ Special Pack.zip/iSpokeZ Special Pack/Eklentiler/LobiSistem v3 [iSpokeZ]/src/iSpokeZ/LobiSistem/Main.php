<?php

/*
  _  _____             _        ______
 (_)/ ____|           | |      |___  /
  _| (___  _ __   ___ | | _____   / /
 | |\___ \| '_ \ / _ \| |/ / _ \ / /
 | |____) | |_) | (_) |   <  __// /__
 |_|_____/| .__/ \___/|_|\_\___/_____|
          | |
          |_|
*/

namespace iSpokeZ\LobiSistem;

use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;
use iSpokeZ\LobiSistem\events\EventListener;

use iSpokeZ\LobiSistem\commands\Lobby;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

class Main extends PluginBase implements Listener {

    /**
     * @var $api
     */
    private static $api;

    /**
     * @return Main
     */

    public static function getAPI(): Main{
        return self::$api;
    }

    public function onLoad(){
        self::$api = $this;
    }

    /*** onEnable ***/
    public function onEnable(){
        $this->getLogger()->info("LobiSistem v.3 activated.");
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        $this->getServer()->getCommandMap()->register("lobi", new Lobby($this));
    }
}